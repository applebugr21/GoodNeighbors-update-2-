//
//  TokenReciever.swift
//  Authenticated
//
//  Created by Jaewoo Seo on 3/29/24.
//

import Amplify
import AmplifyPlugins
import SwiftUI
import AWSMobileClient
import Foundation



class TokenManager {
    var idToken = ""
    var refreshToken = ""
    // var accessToken = ""
    static let shared = TokenManager()
    private var tokenRefreshTimer: Timer?
    
    func bearerToken(completion: @escaping() -> Void) {
        _ = Amplify.Auth.fetchAuthSession { result in
            switch result {
            case .success(let session):
                if(session.isSignedIn) {
                    if let sess = session as? AWSAuthCognitoSession {
                        let result = sess.getCognitoTokens()
                        switch result {
                        case .success(let tokens):
                            //accessToken = tokens.accessToken
                            self.idToken = String(tokens.idToken)
                            self.refreshToken = tokens.refreshToken
                            completion()
                            //print("***First:    ", self.idToken)
                            
                            //self.startTokenRefreshTimer()
                            //gReturnValue = idToken
                            //print(gReturnValue)
                            //print(testToken)
                            //print("idToken: \(idToken)")
                            //print("accessToken: \(accessToken)")
                            //print("refreshToken: \(refreshToken)")
                            
                        case .failure(let error):
                            print("Fetch user tokens failed with error \(error)")
                        }
                    }
                }
            case .failure(let error):
                print("Fetch session failed with error \(error)")
            }
        }
    }
    
    //do to
    func startTokenRefreshTimer() {
        tokenRefreshTimer?.invalidate()
        print("Goes In")
        tokenRefreshTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { _ in
            self.refreshIdTokenWithRefreshToken(refreshToken: self.refreshToken) { result in
                switch result {
                case .success:
                    print("New ID token: \(self.idToken)")
                    
                case .failure(let error):
                    print("Error refreshing ID token: \(error)")
                }
            }
        }
    }
        
        
        
        
    func refreshIdTokenWithRefreshToken(refreshToken: String, completion: @escaping (Result<String, Error>) -> Void) {
        AWSMobileClient.default().federatedSignIn(providerName: "YourProvider", token: refreshToken) { (userState, error) in
            if let error = error {
                // Handle error
                completion(.failure(error))
                return
            }
            
            if let userState = userState, userState == .signedIn {
                // Refresh successful, obtain the new ID token
                AWSMobileClient.default().getTokens { tokens, error in
                    if let error = error {
                        completion(.failure(error))
                        return
                    }
                    
                    if let idToken = tokens?.idToken?.tokenString {
                        completion(.success(idToken))
                    } else {
                        // ID token not available
                        let error = NSError(domain: "YourDomain", code: 0, userInfo: [NSLocalizedDescriptionKey: "ID token not available"])
                        completion(.failure(error))
                    }
                }
            } else {
                // Unexpected user state
                let error = NSError(domain: "YourDomain", code: 0, userInfo: [NSLocalizedDescriptionKey: "Unexpected user state"])
                completion(.failure(error))
            }
        }
    }
}

