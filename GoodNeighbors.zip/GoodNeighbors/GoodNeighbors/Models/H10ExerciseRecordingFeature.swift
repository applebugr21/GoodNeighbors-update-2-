/// Copyright © 2023 Polar Electro Oy. All rights reserved.

import Foundation

struct H10RecordingFeature {
    var isSupported = false
    var isEnabled = false
    var isFetchingRecording = false
}
