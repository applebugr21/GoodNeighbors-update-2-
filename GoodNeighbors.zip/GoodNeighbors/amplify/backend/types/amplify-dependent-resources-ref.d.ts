export type AmplifyDependentResourcesAttributes = {
  "auth": {
    "goodneighborsbc6d1ce6": {
      "AppClientID": "string",
      "AppClientIDWeb": "string",
      "IdentityPoolId": "string",
      "IdentityPoolName": "string",
      "UserPoolArn": "string",
      "UserPoolId": "string",
      "UserPoolName": "string"
    }
  },
  "storage": {
    "s33a6fabff": {
      "BucketName": "string",
      "Region": "string"
    }
  }
}